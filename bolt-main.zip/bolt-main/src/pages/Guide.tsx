import { useState } from 'react';
import { BookOpen, Mail, Brain, Shield, BarChart3, CheckCircle, ChevronRight } from 'lucide-react';

const steps = [
  {
    id: 1,
    title: 'Connect Your Gmail',
    icon: Mail,
    description: 'Securely connect your Gmail inbox using Google OAuth 2.0',
    details: [
      'Click "Configure Gmail Access" in Settings',
      'Authorize access to read and send emails',
      'Your credentials are encrypted and secure',
      'You can revoke access anytime',
    ],
    color: 'blue',
  },
  {
    id: 2,
    title: 'Build Your Knowledge Base',
    icon: Brain,
    description: 'Upload documents to train your AI assistant',
    details: [
      'Navigate to the Knowledge Base page',
      'Upload FAQs, policies, and product guides',
      'Verify each document for accuracy',
      'The AI learns from your content',
    ],
    color: 'green',
  },
  {
    id: 3,
    title: 'Configure AI Guardrails',
    icon: Shield,
    description: 'Set safety rules for automated responses',
    details: [
      'Define sentiment thresholds for blocking',
      'Set urgency levels requiring human review',
      'Enable blocks for negative or angry messages',
      'Choose between auto-send or draft mode',
    ],
    color: 'orange',
  },
  {
    id: 4,
    title: 'Enable AI Autoreply',
    icon: CheckCircle,
    description: 'Activate your AI assistant',
    details: [
      'Go to Settings page',
      'Toggle "Enable AI Autoreply" on',
      'Add your Google Gemini API key',
      'Start receiving automated responses',
    ],
    color: 'purple',
  },
  {
    id: 5,
    title: 'Monitor Performance',
    icon: BarChart3,
    description: 'Track metrics and optimize your setup',
    details: [
      'View time saved on Dashboard',
      'Check AI reply success rate',
      'Review blocked messages in Inbox',
      'Analyze trends in Analytics page',
    ],
    color: 'indigo',
  },
];

export function Guide() {
  const [expandedStep, setExpandedStep] = useState<number | null>(1);

  const getColorClasses = (color: string) => {
    const colors = {
      blue: { bg: 'bg-blue-100', icon: 'text-blue-600', border: 'border-blue-200', text: 'text-blue-900' },
      green: { bg: 'bg-green-100', icon: 'text-green-600', border: 'border-green-200', text: 'text-green-900' },
      orange: { bg: 'bg-orange-100', icon: 'text-orange-600', border: 'border-orange-200', text: 'text-orange-900' },
      purple: { bg: 'bg-purple-100', icon: 'text-purple-600', border: 'border-purple-200', text: 'text-purple-900' },
      indigo: { bg: 'bg-indigo-100', icon: 'text-indigo-600', border: 'border-indigo-200', text: 'text-indigo-900' },
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">How to Use</h1>
            <p className="text-gray-600">Get started in 5 simple steps</p>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-200 p-6 mb-8">
        <h2 className="text-lg font-semibold text-gray-900 mb-3">What This App Does</h2>
        <p className="text-gray-700 leading-relaxed mb-4">
          AI Support Inbox is your intelligent customer support assistant that connects to your Gmail inbox
          and automatically handles customer inquiries using Google's Gemini AI. The system learns from your
          knowledge base, respects safety guardrails, and helps you save hours of manual work every day.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white rounded-lg p-4">
            <p className="text-2xl font-bold text-blue-600 mb-1">5 min</p>
            <p className="text-sm text-gray-600">Average time saved per reply</p>
          </div>
          <div className="bg-white rounded-lg p-4">
            <p className="text-2xl font-bold text-green-600 mb-1">24/7</p>
            <p className="text-sm text-gray-600">AI works around the clock</p>
          </div>
          <div className="bg-white rounded-lg p-4">
            <p className="text-2xl font-bold text-orange-600 mb-1">Safe</p>
            <p className="text-sm text-gray-600">Smart guardrails protect you</p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {steps.map((step, index) => {
          const Icon = step.icon;
          const colors = getColorClasses(step.color);
          const isExpanded = expandedStep === step.id;
          const isCompleted = false;

          return (
            <div key={step.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <button
                onClick={() => setExpandedStep(isExpanded ? null : step.id)}
                className="w-full p-6 flex items-center gap-4 text-left hover:bg-gray-50 transition-colors"
              >
                <div className={`w-12 h-12 ${colors.bg} rounded-lg flex items-center justify-center flex-shrink-0`}>
                  {isCompleted ? (
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  ) : (
                    <Icon className={`w-6 h-6 ${colors.icon}`} />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-sm font-semibold ${colors.text}`}>Step {index + 1}</span>
                    {isCompleted && (
                      <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                        Completed
                      </span>
                    )}
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">{step.title}</h3>
                  <p className="text-sm text-gray-600">{step.description}</p>
                </div>
                <ChevronRight className={`w-5 h-5 text-gray-400 transform transition-transform ${
                  isExpanded ? 'rotate-90' : ''
                }`} />
              </button>

              {isExpanded && (
                <div className="px-6 pb-6 border-t border-gray-100">
                  <div className="pt-6">
                    <h4 className="text-sm font-semibold text-gray-900 mb-3">Steps to Complete:</h4>
                    <ul className="space-y-2">
                      {step.details.map((detail, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <div className={`w-6 h-6 ${colors.bg} rounded-full flex items-center justify-center flex-shrink-0 mt-0.5`}>
                            <span className={`text-xs font-semibold ${colors.icon}`}>{idx + 1}</span>
                          </div>
                          <p className="text-gray-700 flex-1">{detail}</p>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-8 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Need More Help?</h2>
        <div className="space-y-3">
          <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Mail className="w-4 h-4 text-blue-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900 mb-1">Email Support</p>
              <p className="text-sm text-gray-600">Contact us at support@example.com</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
            <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-4 h-4 text-green-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900 mb-1">Documentation</p>
              <p className="text-sm text-gray-600">Visit our help center for detailed guides</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
