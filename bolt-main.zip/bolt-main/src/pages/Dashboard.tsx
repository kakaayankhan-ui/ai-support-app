import { useState, useEffect } from 'react';
import { TrendingUp, Mail, Clock, Shield, CheckCircle, AlertTriangle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface DashboardStats {
  aiEnabled: boolean;
  todayMessages: number;
  todayAiReplies: number;
  todayBlocked: number;
  timeSavedToday: number;
  totalTimeSaved: number;
  weeklyTrend: number;
}

export function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState<DashboardStats>({
    aiEnabled: false,
    todayMessages: 0,
    todayAiReplies: 0,
    todayBlocked: 0,
    timeSavedToday: 0,
    totalTimeSaved: 0,
    weeklyTrend: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadDashboardData();
    }
  }, [user]);

  const loadDashboardData = async () => {
    if (!user) return;

    try {
      const { data: settings } = await supabase
        .from('user_settings')
        .select('ai_autoreply_enabled')
        .eq('user_id', user.id)
        .maybeSingle();

      const today = new Date().toISOString().split('T')[0];
      const { data: todayAnalytics } = await supabase
        .from('analytics')
        .select('*')
        .eq('user_id', user.id)
        .eq('date', today)
        .maybeSingle();

      const { data: totalAnalytics } = await supabase
        .from('analytics')
        .select('time_saved_minutes')
        .eq('user_id', user.id);

      const totalMinutes = totalAnalytics?.reduce((sum, record) => sum + record.time_saved_minutes, 0) || 0;

      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      const { data: weeklyData } = await supabase
        .from('analytics')
        .select('ai_replies_sent')
        .eq('user_id', user.id)
        .gte('date', weekAgo.toISOString().split('T')[0]);

      const weeklyReplies = weeklyData?.reduce((sum, record) => sum + record.ai_replies_sent, 0) || 0;

      setStats({
        aiEnabled: settings?.ai_autoreply_enabled || false,
        todayMessages: todayAnalytics?.total_messages_received || 0,
        todayAiReplies: todayAnalytics?.ai_replies_sent || 0,
        todayBlocked: todayAnalytics?.ai_replies_blocked || 0,
        timeSavedToday: todayAnalytics?.time_saved_minutes || 0,
        totalTimeSaved: totalMinutes,
        weeklyTrend: weeklyReplies,
      });
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Your AI inbox performance at a glance</p>
        </div>
        <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${stats.aiEnabled ? 'bg-green-100' : 'bg-gray-100'}`}>
          <div className={`w-3 h-3 rounded-full ${stats.aiEnabled ? 'bg-green-500' : 'bg-gray-400'}`} />
          <span className={`font-medium ${stats.aiEnabled ? 'text-green-700' : 'text-gray-600'}`}>
            AI {stats.aiEnabled ? 'Active' : 'Inactive'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200 hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Today's Messages</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.todayMessages}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Mail className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-4">Received in your inbox</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200 hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">AI Replies Today</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.todayAiReplies}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-4">Automatically handled</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200 hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Blocked by Guards</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.todayBlocked}</p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-4">Required human review</p>
        </div>

        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl shadow-lg p-6 text-white md:col-span-2">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-blue-100 text-sm font-medium">Time Saved Today</p>
              <p className="text-4xl font-bold mt-2">{formatTime(stats.timeSavedToday)}</p>
              <p className="text-blue-100 text-sm mt-4">Total: {formatTime(stats.totalTimeSaved)}</p>
            </div>
            <div className="w-14 h-14 bg-blue-500 bg-opacity-50 rounded-lg flex items-center justify-center">
              <Clock className="w-7 h-7 text-white" />
            </div>
          </div>
          <div className="mt-6 pt-4 border-t border-blue-500">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              <span className="text-sm">Based on avg 5 min per manual reply</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm font-medium text-gray-600">Weekly Activity</p>
            <TrendingUp className="w-5 h-5 text-green-600" />
          </div>
          <p className="text-3xl font-bold text-gray-900">{stats.weeklyTrend}</p>
          <p className="text-sm text-gray-500 mt-2">AI replies this week</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-blue-600 hover:bg-blue-50 transition-all">
            <Mail className="w-5 h-5 text-blue-600" />
            <div className="text-left">
              <p className="font-medium text-gray-900">View Inbox</p>
              <p className="text-sm text-gray-500">Check pending messages</p>
            </div>
          </button>
          <button className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-blue-600 hover:bg-blue-50 transition-all">
            <Shield className="w-5 h-5 text-blue-600" />
            <div className="text-left">
              <p className="font-medium text-gray-900">Configure Guards</p>
              <p className="text-sm text-gray-500">Adjust AI safety rules</p>
            </div>
          </button>
          <button className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-blue-600 hover:bg-blue-50 transition-all">
            <AlertTriangle className="w-5 h-5 text-blue-600" />
            <div className="text-left">
              <p className="font-medium text-gray-900">Update Knowledge</p>
              <p className="text-sm text-gray-500">Train AI responses</p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
