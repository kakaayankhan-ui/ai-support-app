import { useState, useEffect } from 'react';
import { Shield, Key, Mail, Save, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface UserSettings {
  ai_autoreply_enabled: boolean;
  sentiment_threshold: number;
  urgency_threshold: number;
  block_negative_sentiment: boolean;
  block_angry_sentiment: boolean;
  block_high_urgency: boolean;
  auto_send_enabled: boolean;
  gemini_api_key: string | null;
}

export function Settings() {
  const { user } = useAuth();
  const [settings, setSettings] = useState<UserSettings>({
    ai_autoreply_enabled: false,
    sentiment_threshold: -0.3,
    urgency_threshold: 0.7,
    block_negative_sentiment: true,
    block_angry_sentiment: true,
    block_high_urgency: true,
    auto_send_enabled: false,
    gemini_api_key: null,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);

  useEffect(() => {
    if (user) {
      loadSettings();
    }
  }, [user]);

  const loadSettings = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('user_settings')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setSettings({
          ai_autoreply_enabled: data.ai_autoreply_enabled,
          sentiment_threshold: data.sentiment_threshold,
          urgency_threshold: data.urgency_threshold,
          block_negative_sentiment: data.block_negative_sentiment,
          block_angry_sentiment: data.block_angry_sentiment,
          block_high_urgency: data.block_high_urgency,
          auto_send_enabled: data.auto_send_enabled,
          gemini_api_key: data.gemini_api_key,
        });
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!user) return;

    setSaving(true);
    try {
      const { data: existing } = await supabase
        .from('user_settings')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      if (existing) {
        const { error } = await supabase
          .from('user_settings')
          .update({
            ...settings,
            updated_at: new Date().toISOString(),
          })
          .eq('user_id', user.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('user_settings')
          .insert({
            user_id: user.id,
            ...settings,
          });

        if (error) throw error;
      }

      alert('Settings saved successfully!');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600 mt-1">Configure your AI assistant and integrations</p>
      </div>

      <div className="space-y-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Shield className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">AI Autoreply Control</h2>
              <p className="text-sm text-gray-600">Enable or disable AI-powered responses</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">Enable AI Autoreply</p>
                <p className="text-sm text-gray-600">Allow AI to automatically respond to messages</p>
              </div>
              <button
                onClick={() => setSettings({ ...settings, ai_autoreply_enabled: !settings.ai_autoreply_enabled })}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  settings.ai_autoreply_enabled ? 'bg-blue-600' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    settings.ai_autoreply_enabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">Auto-Send Replies</p>
                <p className="text-sm text-gray-600">Send AI responses automatically vs saving as drafts</p>
              </div>
              <button
                onClick={() => setSettings({ ...settings, auto_send_enabled: !settings.auto_send_enabled })}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  settings.auto_send_enabled ? 'bg-blue-600' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    settings.auto_send_enabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Guardrail Configuration</h2>
              <p className="text-sm text-gray-600">Set safety rules for AI responses</p>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sentiment Threshold
              </label>
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min="-1"
                  max="0"
                  step="0.1"
                  value={settings.sentiment_threshold}
                  onChange={(e) => setSettings({ ...settings, sentiment_threshold: parseFloat(e.target.value) })}
                  className="flex-1"
                />
                <span className="text-sm font-medium text-gray-900 w-12">{settings.sentiment_threshold.toFixed(1)}</span>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Block AI replies if sentiment is below this value (-1 = very negative, 0 = neutral)
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Urgency Threshold
              </label>
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={settings.urgency_threshold}
                  onChange={(e) => setSettings({ ...settings, urgency_threshold: parseFloat(e.target.value) })}
                  className="flex-1"
                />
                <span className="text-sm font-medium text-gray-900 w-12">{settings.urgency_threshold.toFixed(1)}</span>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Block AI replies if urgency is above this value (0 = low urgency, 1 = critical)
              </p>
            </div>

            <div className="space-y-3 pt-4 border-t border-gray-200">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.block_negative_sentiment}
                  onChange={(e) => setSettings({ ...settings, block_negative_sentiment: e.target.checked })}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                />
                <div>
                  <p className="text-sm font-medium text-gray-900">Block Negative Sentiment</p>
                  <p className="text-xs text-gray-600">Prevent AI from replying to negative messages</p>
                </div>
              </label>

              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.block_angry_sentiment}
                  onChange={(e) => setSettings({ ...settings, block_angry_sentiment: e.target.checked })}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                />
                <div>
                  <p className="text-sm font-medium text-gray-900">Block Angry Sentiment</p>
                  <p className="text-xs text-gray-600">Prevent AI from replying to angry messages</p>
                </div>
              </label>

              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.block_high_urgency}
                  onChange={(e) => setSettings({ ...settings, block_high_urgency: e.target.checked })}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                />
                <div>
                  <p className="text-sm font-medium text-gray-900">Block High Urgency</p>
                  <p className="text-xs text-gray-600">Prevent AI from replying to urgent/critical messages</p>
                </div>
              </label>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <Key className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">API Configuration</h2>
              <p className="text-sm text-gray-600">Configure external service integrations</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Google Gemini API Key
              </label>
              <div className="flex gap-2">
                <input
                  type={showApiKey ? 'text' : 'password'}
                  value={settings.gemini_api_key || ''}
                  onChange={(e) => setSettings({ ...settings, gemini_api_key: e.target.value })}
                  placeholder="Enter your Gemini API key"
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
                <button
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  {showApiKey ? 'Hide' : 'Show'}
                </button>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Get your API key from <a href="https://makersuite.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Google AI Studio</a>
              </p>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-blue-900 mb-1">Gmail OAuth Status</p>
                  <p className="text-sm text-blue-700">
                    OAuth connection required for Gmail integration. Click to configure.
                  </p>
                  <button className="mt-2 text-sm text-blue-600 hover:text-blue-700 font-medium">
                    Configure Gmail Access →
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white font-medium py-3 px-6 rounded-lg transition-colors shadow-sm"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </div>
    </div>
  );
}
