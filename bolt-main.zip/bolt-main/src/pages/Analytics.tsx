import { useState, useEffect } from 'react';
import { TrendingUp, Clock, CheckCircle, Shield, Smile, Calendar } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface AnalyticsData {
  date: string;
  total_messages_received: number;
  ai_replies_sent: number;
  ai_replies_blocked: number;
  time_saved_minutes: number;
  avg_sentiment_score: number;
  high_urgency_count: number;
  manual_replies_required: number;
}

export function Analytics() {
  const { user } = useAuth();
  const [analytics, setAnalytics] = useState<AnalyticsData[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');

  useEffect(() => {
    if (user) {
      loadAnalytics();
    }
  }, [user, timeRange]);

  const loadAnalytics = async () => {
    if (!user) return;

    try {
      const daysAgo = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - daysAgo);

      const { data, error } = await supabase
        .from('analytics')
        .select('*')
        .eq('user_id', user.id)
        .gte('date', startDate.toISOString().split('T')[0])
        .order('date', { ascending: false });

      if (error) throw error;
      setAnalytics(data || []);
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateTotals = () => {
    return analytics.reduce(
      (acc, day) => ({
        messages: acc.messages + day.total_messages_received,
        aiReplies: acc.aiReplies + day.ai_replies_sent,
        blocked: acc.blocked + day.ai_replies_blocked,
        timeSaved: acc.timeSaved + day.time_saved_minutes,
        highUrgency: acc.highUrgency + day.high_urgency_count,
      }),
      { messages: 0, aiReplies: 0, blocked: 0, timeSaved: 0, highUrgency: 0 }
    );
  };

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 24) {
      const days = Math.floor(hours / 24);
      const remainingHours = hours % 24;
      return `${days}d ${remainingHours}h`;
    }
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };

  const calculateCSAT = () => {
    if (analytics.length === 0) return 0;
    const avgSentiment = analytics.reduce((sum, day) => sum + day.avg_sentiment_score, 0) / analytics.length;
    return Math.round(((avgSentiment + 1) / 2) * 100);
  };

  const calculateGuardrailSuccessRate = () => {
    const totals = calculateTotals();
    if (totals.blocked === 0) return 100;
    return Math.round((totals.blocked / (totals.blocked + totals.highUrgency)) * 100);
  };

  const calculateEfficiency = () => {
    const totals = calculateTotals();
    if (totals.messages === 0) return 0;
    return Math.round((totals.aiReplies / totals.messages) * 100);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const totals = calculateTotals();
  const csat = calculateCSAT();
  const guardrailRate = calculateGuardrailSuccessRate();
  const efficiency = calculateEfficiency();

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Analytics</h1>
          <p className="text-gray-600 mt-1">Track your AI performance and time savings</p>
        </div>
        <div className="flex gap-2 bg-white rounded-lg shadow-sm border border-gray-200 p-1">
          {(['7d', '30d', '90d'] as const).map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                timeRange === range
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              {range === '7d' ? '7 Days' : range === '30d' ? '30 Days' : '90 Days'}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl shadow-lg p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <p className="text-blue-100 text-sm font-medium">Total Time Saved</p>
            <Clock className="w-8 h-8 text-blue-200" />
          </div>
          <p className="text-4xl font-bold mb-2">{formatTime(totals.timeSaved)}</p>
          <p className="text-blue-100 text-sm">
            Based on 5 min avg per reply
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <p className="text-gray-600 text-sm font-medium">AI Replies</p>
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <p className="text-4xl font-bold text-gray-900 mb-2">{totals.aiReplies}</p>
          <p className="text-sm text-gray-500">
            {efficiency}% automation rate
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <p className="text-gray-600 text-sm font-medium">Customer Satisfaction</p>
            <Smile className="w-8 h-8 text-yellow-500" />
          </div>
          <p className="text-4xl font-bold text-gray-900 mb-2">{csat}%</p>
          <p className="text-sm text-gray-500">
            Based on sentiment analysis
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <p className="text-gray-600 text-sm font-medium">Guardrail Success</p>
            <Shield className="w-8 h-8 text-orange-600" />
          </div>
          <p className="text-4xl font-bold text-gray-900 mb-2">{guardrailRate}%</p>
          <p className="text-sm text-gray-500">
            {totals.blocked} replies blocked
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Performance Overview</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
              <div>
                <p className="text-sm text-blue-600 font-medium">Total Messages</p>
                <p className="text-2xl font-bold text-blue-900">{totals.messages}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-blue-600" />
            </div>
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
              <div>
                <p className="text-sm text-green-600 font-medium">AI Handled</p>
                <p className="text-2xl font-bold text-green-900">{totals.aiReplies}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <div className="flex items-center justify-between p-4 bg-orange-50 rounded-lg">
              <div>
                <p className="text-sm text-orange-600 font-medium">Blocked by Guards</p>
                <p className="text-2xl font-bold text-orange-900">{totals.blocked}</p>
              </div>
              <Shield className="w-8 h-8 text-orange-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Time Savings Breakdown</h2>
          <div className="space-y-4">
            <div className="border-l-4 border-blue-600 pl-4">
              <p className="text-sm text-gray-600 mb-1">Average Time per AI Reply</p>
              <p className="text-xl font-bold text-gray-900">~2 seconds</p>
            </div>
            <div className="border-l-4 border-orange-600 pl-4">
              <p className="text-sm text-gray-600 mb-1">Average Manual Reply Time</p>
              <p className="text-xl font-bold text-gray-900">~5 minutes</p>
            </div>
            <div className="border-l-4 border-green-600 pl-4">
              <p className="text-sm text-gray-600 mb-1">Total Time Saved</p>
              <p className="text-xl font-bold text-gray-900">{formatTime(totals.timeSaved)}</p>
            </div>
            <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-lg p-4 mt-4">
              <p className="text-sm text-gray-700 mb-1">Cost Savings Estimate</p>
              <p className="text-2xl font-bold text-gray-900">
                ${Math.round((totals.timeSaved / 60) * 25)}
              </p>
              <p className="text-xs text-gray-600 mt-1">Based on $25/hour agent rate</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Daily Breakdown
        </h2>
        {analytics.length === 0 ? (
          <p className="text-center text-gray-500 py-8">No data available for selected time range</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Date</th>
                  <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Messages</th>
                  <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">AI Replies</th>
                  <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Blocked</th>
                  <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Time Saved</th>
                </tr>
              </thead>
              <tbody>
                {analytics.map((day) => (
                  <tr key={day.date} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4 text-sm text-gray-900">
                      {new Date(day.date).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-900 text-right">
                      {day.total_messages_received}
                    </td>
                    <td className="py-3 px-4 text-sm text-green-600 font-medium text-right">
                      {day.ai_replies_sent}
                    </td>
                    <td className="py-3 px-4 text-sm text-orange-600 font-medium text-right">
                      {day.ai_replies_blocked}
                    </td>
                    <td className="py-3 px-4 text-sm text-blue-600 font-medium text-right">
                      {formatTime(day.time_saved_minutes)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
