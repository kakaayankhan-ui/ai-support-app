import { useState, useEffect } from 'react';
import { Mail, CheckCircle, Shield, AlertCircle, Clock, User } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface Message {
  id: string;
  gmail_message_id: string;
  subject: string;
  from_email: string;
  from_name: string;
  body: string;
  received_at: string;
  sentiment_label: string | null;
  urgency_score: number | null;
  ai_replied: boolean;
  ai_reply_sent: boolean;
  ai_reply_blocked: boolean;
  block_reason: string | null;
  ai_response_content: string | null;
  manual_reply_required: boolean;
}

export function Inbox() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);

  useEffect(() => {
    if (user) {
      loadMessages();
    }
  }, [user]);

  const loadMessages = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('user_id', user.id)
        .order('received_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setMessages(data || []);
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const getSentimentColor = (label: string | null) => {
    switch (label) {
      case 'positive':
        return 'text-green-600 bg-green-100';
      case 'neutral':
        return 'text-gray-600 bg-gray-100';
      case 'negative':
        return 'text-orange-600 bg-orange-100';
      case 'angry':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusBadge = (message: Message) => {
    if (message.ai_reply_blocked) {
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-medium">
          <Shield className="w-3.5 h-3.5" />
          Blocked
        </div>
      );
    }
    if (message.ai_reply_sent) {
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
          <CheckCircle className="w-3.5 h-3.5" />
          AI Replied
        </div>
      );
    }
    if (message.manual_reply_required) {
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-red-100 text-red-700 rounded-full text-xs font-medium">
          <AlertCircle className="w-3.5 h-3.5" />
          Review Needed
        </div>
      );
    }
    return (
      <div className="flex items-center gap-1.5 px-2.5 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">
        <Clock className="w-3.5 h-3.5" />
        Pending
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Inbox</h1>
        <p className="text-gray-600 mt-1">Manage your customer support messages</p>
      </div>

      {messages.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm p-12 text-center border border-gray-200">
          <Mail className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No messages yet</h3>
          <p className="text-gray-600">
            Connect your Gmail account to start receiving messages
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-3">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
              <p className="text-sm font-medium text-gray-600">
                {messages.length} messages
              </p>
            </div>

            <div className="space-y-2">
              {messages.map((message) => (
                <button
                  key={message.id}
                  onClick={() => setSelectedMessage(message)}
                  className={`w-full text-left bg-white rounded-lg shadow-sm border p-4 transition-all hover:shadow-md ${
                    selectedMessage?.id === message.id
                      ? 'border-blue-600 ring-2 ring-blue-100'
                      : 'border-gray-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <User className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-gray-900 truncate">
                          {message.from_name || message.from_email}
                        </p>
                        <p className="text-sm text-gray-500 truncate">{message.from_email}</p>
                      </div>
                    </div>
                    {getStatusBadge(message)}
                  </div>

                  <h3 className="font-medium text-gray-900 mb-1 truncate">
                    {message.subject || '(No subject)'}
                  </h3>

                  <p className="text-sm text-gray-600 line-clamp-2 mb-3">
                    {message.body.substring(0, 120)}...
                  </p>

                  <div className="flex items-center gap-2 flex-wrap">
                    {message.sentiment_label && (
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getSentimentColor(message.sentiment_label)}`}>
                        {message.sentiment_label}
                      </span>
                    )}
                    {message.urgency_score !== null && message.urgency_score > 0.7 && (
                      <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-700">
                        High Priority
                      </span>
                    )}
                    <span className="text-xs text-gray-500">
                      {new Date(message.received_at).toLocaleDateString()}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="lg:sticky lg:top-6 h-fit">
            {selectedMessage ? (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">
                        {selectedMessage.from_name || selectedMessage.from_email}
                      </p>
                      <p className="text-sm text-gray-500">{selectedMessage.from_email}</p>
                    </div>
                  </div>
                  {getStatusBadge(selectedMessage)}
                </div>

                <div className="mb-4 pb-4 border-b border-gray-200">
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">
                    {selectedMessage.subject || '(No subject)'}
                  </h2>
                  <p className="text-sm text-gray-500">
                    {new Date(selectedMessage.received_at).toLocaleString()}
                  </p>
                </div>

                <div className="mb-6">
                  <h3 className="text-sm font-semibold text-gray-900 mb-2">Message</h3>
                  <div className="bg-gray-50 rounded-lg p-4 text-gray-700 whitespace-pre-wrap">
                    {selectedMessage.body}
                  </div>
                </div>

                {selectedMessage.ai_reply_blocked && selectedMessage.block_reason && (
                  <div className="mb-6 p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <div className="flex items-start gap-3">
                      <Shield className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-orange-900 mb-1">AI Reply Blocked</p>
                        <p className="text-sm text-orange-700">{selectedMessage.block_reason}</p>
                      </div>
                    </div>
                  </div>
                )}

                {selectedMessage.ai_response_content && (
                  <div className="mb-6">
                    <h3 className="text-sm font-semibold text-gray-900 mb-2">AI Response</h3>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-gray-700 whitespace-pre-wrap">
                      {selectedMessage.ai_response_content}
                    </div>
                  </div>
                )}

                <div className="flex gap-3">
                  <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors">
                    Reply
                  </button>
                  <button className="px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors">
                    Archive
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
                <Mail className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600">Select a message to view details</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
