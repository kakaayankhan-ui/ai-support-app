export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          google_oauth_token: string | null
          google_refresh_token: string | null
          gmail_address: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          google_oauth_token?: string | null
          google_refresh_token?: string | null
          gmail_address?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          google_oauth_token?: string | null
          google_refresh_token?: string | null
          gmail_address?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      knowledge_base: {
        Row: {
          id: string
          user_id: string
          title: string
          content: string
          file_type: string
          verified: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          title: string
          content: string
          file_type?: string
          verified?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          title?: string
          content?: string
          file_type?: string
          verified?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      messages: {
        Row: {
          id: string
          user_id: string
          gmail_message_id: string
          thread_id: string
          subject: string
          from_email: string
          from_name: string
          body: string
          received_at: string
          sentiment_score: number | null
          sentiment_label: string | null
          urgency_score: number | null
          ai_replied: boolean
          ai_reply_sent: boolean
          ai_reply_blocked: boolean
          block_reason: string | null
          ai_response_content: string | null
          manual_reply_required: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          gmail_message_id: string
          thread_id: string
          subject?: string
          from_email: string
          from_name?: string
          body?: string
          received_at?: string
          sentiment_score?: number | null
          sentiment_label?: string | null
          urgency_score?: number | null
          ai_replied?: boolean
          ai_reply_sent?: boolean
          ai_reply_blocked?: boolean
          block_reason?: string | null
          ai_response_content?: string | null
          manual_reply_required?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          gmail_message_id?: string
          thread_id?: string
          subject?: string
          from_email?: string
          from_name?: string
          body?: string
          received_at?: string
          sentiment_score?: number | null
          sentiment_label?: string | null
          urgency_score?: number | null
          ai_replied?: boolean
          ai_reply_sent?: boolean
          ai_reply_blocked?: boolean
          block_reason?: string | null
          ai_response_content?: string | null
          manual_reply_required?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      user_settings: {
        Row: {
          id: string
          user_id: string
          ai_autoreply_enabled: boolean
          sentiment_threshold: number
          urgency_threshold: number
          block_negative_sentiment: boolean
          block_angry_sentiment: boolean
          block_high_urgency: boolean
          auto_send_enabled: boolean
          gemini_api_key: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          ai_autoreply_enabled?: boolean
          sentiment_threshold?: number
          urgency_threshold?: number
          block_negative_sentiment?: boolean
          block_angry_sentiment?: boolean
          block_high_urgency?: boolean
          auto_send_enabled?: boolean
          gemini_api_key?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          ai_autoreply_enabled?: boolean
          sentiment_threshold?: number
          urgency_threshold?: number
          block_negative_sentiment?: boolean
          block_angry_sentiment?: boolean
          block_high_urgency?: boolean
          auto_send_enabled?: boolean
          gemini_api_key?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      analytics: {
        Row: {
          id: string
          user_id: string
          date: string
          total_messages_received: number
          ai_replies_sent: number
          ai_replies_blocked: number
          time_saved_minutes: number
          avg_sentiment_score: number
          high_urgency_count: number
          manual_replies_required: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          date: string
          total_messages_received?: number
          ai_replies_sent?: number
          ai_replies_blocked?: number
          time_saved_minutes?: number
          avg_sentiment_score?: number
          high_urgency_count?: number
          manual_replies_required?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          date?: string
          total_messages_received?: number
          ai_replies_sent?: number
          ai_replies_blocked?: number
          time_saved_minutes?: number
          avg_sentiment_score?: number
          high_urgency_count?: number
          manual_replies_required?: number
          created_at?: string
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
