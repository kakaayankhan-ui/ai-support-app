/*
  # Initial Schema for AI-Powered Customer Support Inbox

  ## Overview
  This migration creates the foundational database schema for a Progressive Web App
  that provides AI-powered customer support inbox management with Gmail integration
  and Gemini AI response generation.

  ## New Tables

  ### 1. `users`
  Stores user account information and OAuth tokens
  - `id` (uuid, primary key): Unique user identifier
  - `email` (text, unique): User's email address
  - `google_oauth_token` (text): Encrypted OAuth access token
  - `google_refresh_token` (text): Encrypted OAuth refresh token
  - `gmail_address` (text): Connected Gmail inbox address
  - `created_at` (timestamptz): Account creation timestamp
  - `updated_at` (timestamptz): Last update timestamp

  ### 2. `knowledge_base`
  Stores training documents and FAQs for AI model grounding
  - `id` (uuid, primary key): Unique document identifier
  - `user_id` (uuid, foreign key): Owner of the document
  - `title` (text): Document title
  - `content` (text): Full document content for AI training
  - `file_type` (text): Original file format (pdf, txt, docx, etc.)
  - `verified` (boolean): Whether document has been verified by user
  - `created_at` (timestamptz): Upload timestamp
  - `updated_at` (timestamptz): Last modification timestamp

  ### 3. `messages`
  Stores Gmail messages and AI response tracking
  - `id` (uuid, primary key): Unique message identifier
  - `user_id` (uuid, foreign key): Owner of the inbox
  - `gmail_message_id` (text, unique): Gmail API message ID
  - `thread_id` (text): Gmail thread identifier
  - `subject` (text): Email subject line
  - `from_email` (text): Sender email address
  - `from_name` (text): Sender display name
  - `body` (text): Message body content
  - `received_at` (timestamptz): When email was received
  - `sentiment_score` (numeric): AI-analyzed sentiment (-1 to 1)
  - `sentiment_label` (text): Sentiment classification (positive, neutral, negative, angry)
  - `urgency_score` (numeric): AI-analyzed urgency level (0 to 1)
  - `ai_replied` (boolean): Whether AI generated a reply
  - `ai_reply_sent` (boolean): Whether AI reply was actually sent
  - `ai_reply_blocked` (boolean): Whether guardrails blocked the reply
  - `block_reason` (text): Reason for guardrail block
  - `ai_response_content` (text): Generated AI response
  - `manual_reply_required` (boolean): Flagged for human attention
  - `created_at` (timestamptz): Record creation timestamp
  - `updated_at` (timestamptz): Last update timestamp

  ### 4. `user_settings`
  Stores user preferences and AI configuration
  - `id` (uuid, primary key): Unique settings identifier
  - `user_id` (uuid, foreign key, unique): Settings owner
  - `ai_autoreply_enabled` (boolean): Global AI autoreply toggle
  - `sentiment_threshold` (numeric): Block replies below this sentiment (-1 to 1)
  - `urgency_threshold` (numeric): Block replies above this urgency (0 to 1)
  - `block_negative_sentiment` (boolean): Block replies to negative messages
  - `block_angry_sentiment` (boolean): Block replies to angry messages
  - `block_high_urgency` (boolean): Block replies to urgent messages
  - `auto_send_enabled` (boolean): Auto-send vs draft-only mode
  - `gemini_api_key` (text): User's Gemini API key (encrypted)
  - `created_at` (timestamptz): Settings creation timestamp
  - `updated_at` (timestamptz): Last update timestamp

  ### 5. `analytics`
  Stores aggregated analytics data for dashboard metrics
  - `id` (uuid, primary key): Unique analytics record identifier
  - `user_id` (uuid, foreign key): Analytics owner
  - `date` (date): Analytics date
  - `total_messages_received` (integer): Messages received on this date
  - `ai_replies_sent` (integer): Successful AI replies
  - `ai_replies_blocked` (integer): Replies blocked by guardrails
  - `time_saved_minutes` (integer): Estimated time saved (AI replies × avg response time)
  - `avg_sentiment_score` (numeric): Average sentiment of incoming messages
  - `high_urgency_count` (integer): Count of high-urgency messages
  - `manual_replies_required` (integer): Messages flagged for human attention
  - `created_at` (timestamptz): Record creation timestamp
  - `updated_at` (timestamptz): Last update timestamp

  ## Security

  ### Row Level Security (RLS)
  All tables have RLS enabled with policies ensuring users can only access their own data.

  ### Policies
  - Users can read, insert, update their own records
  - All policies verify authentication via `auth.uid()`
  - No cross-user data access is permitted

  ## Important Notes

  1. **OAuth Token Security**: Google OAuth tokens should be encrypted at the application layer
  2. **Gemini API Key**: Should be encrypted before storage
  3. **Default Settings**: New users get safe default settings (AI disabled, conservative thresholds)
  4. **Analytics Aggregation**: Daily analytics should be computed via background jobs
  5. **Message Retention**: Consider implementing a data retention policy
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  google_oauth_token text,
  google_refresh_token text,
  gmail_address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own data"
  ON users FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create knowledge_base table
CREATE TABLE IF NOT EXISTS knowledge_base (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL,
  file_type text DEFAULT 'txt',
  verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE knowledge_base ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own knowledge base"
  ON knowledge_base FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own knowledge base"
  ON knowledge_base FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own knowledge base"
  ON knowledge_base FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own knowledge base"
  ON knowledge_base FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  gmail_message_id text UNIQUE NOT NULL,
  thread_id text NOT NULL,
  subject text DEFAULT '',
  from_email text NOT NULL,
  from_name text DEFAULT '',
  body text DEFAULT '',
  received_at timestamptz DEFAULT now(),
  sentiment_score numeric,
  sentiment_label text,
  urgency_score numeric,
  ai_replied boolean DEFAULT false,
  ai_reply_sent boolean DEFAULT false,
  ai_reply_blocked boolean DEFAULT false,
  block_reason text,
  ai_response_content text,
  manual_reply_required boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own messages"
  ON messages FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own messages"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own messages"
  ON messages FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own messages"
  ON messages FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create user_settings table
CREATE TABLE IF NOT EXISTS user_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  ai_autoreply_enabled boolean DEFAULT false,
  sentiment_threshold numeric DEFAULT -0.3,
  urgency_threshold numeric DEFAULT 0.7,
  block_negative_sentiment boolean DEFAULT true,
  block_angry_sentiment boolean DEFAULT true,
  block_high_urgency boolean DEFAULT true,
  auto_send_enabled boolean DEFAULT false,
  gemini_api_key text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own settings"
  ON user_settings FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own settings"
  ON user_settings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own settings"
  ON user_settings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create analytics table
CREATE TABLE IF NOT EXISTS analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date date NOT NULL,
  total_messages_received integer DEFAULT 0,
  ai_replies_sent integer DEFAULT 0,
  ai_replies_blocked integer DEFAULT 0,
  time_saved_minutes integer DEFAULT 0,
  avg_sentiment_score numeric DEFAULT 0,
  high_urgency_count integer DEFAULT 0,
  manual_replies_required integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, date)
);

ALTER TABLE analytics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own analytics"
  ON analytics FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own analytics"
  ON analytics FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own analytics"
  ON analytics FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_knowledge_base_user_id ON knowledge_base(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_user_id ON messages(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_received_at ON messages(received_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_gmail_id ON messages(gmail_message_id);
CREATE INDEX IF NOT EXISTS idx_analytics_user_date ON analytics(user_id, date DESC);
